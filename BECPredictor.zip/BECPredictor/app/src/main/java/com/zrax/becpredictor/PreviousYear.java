package com.zrax.becpredictor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.rajat.pdfviewer.PdfViewerActivity;
import com.zrax.becpredictor.databinding.ActivityPreviousYearBinding;

public class PreviousYear extends AppCompatActivity {
    ActivityPreviousYearBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_previous_year);
        binding = ActivityPreviousYearBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        binding.PY1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(

                        // Opening pdf from assets folder

                        PdfViewerActivity.Companion.launchPdfFromPath(
                                PreviousYear.this,
                                "2k21.pdf",
                                "2021 pdf",
                                "assets",
                                false,
                                true
                        )
                );

            }
        });

        binding.PY2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(

                        // Opening pdf from assets folder

                        PdfViewerActivity.Companion.launchPdfFromPath(
                                PreviousYear.this,
                                "2k20.pdf",
                                "2020 pdf",
                                "assets",
                                false,
                                true
                        )
                );
            }
        });

        binding.PY3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(

                        // Opening pdf from assets folder

                        PdfViewerActivity.Companion.launchPdfFromPath(
                                PreviousYear.this,
                                "2k19.pdf",
                                "2019 pdf",
                                "assets",
                                false,
                                true
                        )
                );
            }
        });


    }
}