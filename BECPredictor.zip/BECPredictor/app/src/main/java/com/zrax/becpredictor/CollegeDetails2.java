package com.zrax.becpredictor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class CollegeDetails2 extends AppCompatActivity {

    int a = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college_details2);

        a = getIntent().getIntExtra("id", 1);

        String name = getIntent().getStringExtra("name");

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });



        switch (a){

            case 1 :       setText(name, "Government", "1954", getResources().getString(R.string.s1 ));                                   break;
            case 2 :       setText(name, "Government", "1960", getResources().getString(R.string.s2 ));                                   break;
            case 3 :       setText(name, "Government", "2008", getResources().getString(R.string.s3 ));                                   break;
            case 4 :       setText(name, "Government", "2008", getResources().getString(R.string.s4 ));                                   break;
            case 5 :       setText(name, "Government", "2008", getResources().getString(R.string.s5 ));                                   break;
            case 6 :       setText(name, "Government", "1958", getResources().getString(R.string.s6 ));                                   break;
            case 7 :       setText(name, "Government", "2012", getResources().getString(R.string.s7 ));                                   break;
            case 8 :       setText(name, "Government", "2016", getResources().getString(R.string.s8 ));                                   break;
            case 9 :       setText(name, "Government", "2016", getResources().getString(R.string.s9 ));                                   break;
            case 10:       setText(name, "Government", "2016", getResources().getString(R.string.s10));                                   break;
            case 11:       setText(name, "Government", "2016", getResources().getString(R.string.s11));                                   break;
            case 12:       setText(name, "Government", "2016", getResources().getString(R.string.s12));                                   break;
            case 13:       setText(name, "Government", "2017", getResources().getString(R.string.s13));                                   break;
            case 14:       setText(name, "Government", "2017", getResources().getString(R.string.s14));                                   break;
            case 15:       setText(name, "Government", "2017", getResources().getString(R.string.s15));                                   break;
            case 16:       setText(name, "Government", "2018", getResources().getString(R.string.s16));                                   break;
            case 17:       setText(name, "Government", "2018", getResources().getString(R.string.s17));                                   break;
            case 18:       setText(name, "Government", "2018", getResources().getString(R.string.s18));                                   break;
            case 19:       setText(name, "Government", "2019", getResources().getString(R.string.s19));                                   break;
            case 20:       setText(name, "Government", "2019", getResources().getString(R.string.s20));                                   break;
            case 21:       setText(name, "Government", "2019", getResources().getString(R.string.s21));                                   break;
            case 22:       setText(name, "Government", "2019", getResources().getString(R.string.s22));                                   break;
            case 23:       setText(name, "Government", "2019", getResources().getString(R.string.s23));                                   break;
            case 24:       setText(name, "Government", "2019", getResources().getString(R.string.s24));                                   break;
            case 25:       setText(name, "Government", "2019", getResources().getString(R.string.s25));                                   break;
            case 26:       setText(name, "Government", "2018", getResources().getString(R.string.s26));                                   break;
            case 27:       setText(name, "Government", "2019", getResources().getString(R.string.s27));                                   break;
            case 28:       setText(name, "Government", "2018", getResources().getString(R.string.s28));                                   break;
            case 29:       setText(name, "Government", "2019", getResources().getString(R.string.s29));                                   break;
            case 30:       setText(name, "Government", "2019", getResources().getString(R.string.s30));                                   break;
            case 31:       setText(name, "Government", "2019", getResources().getString(R.string.s31));                                   break;
            case 32:       setText(name, "Government", "2019", getResources().getString(R.string.s32));                                   break;
            case 33:       setText(name, "Government", "2019", getResources().getString(R.string.s33));                                   break;
            case 34:       setText(name, "Government", "2019", getResources().getString(R.string.s34));                                   break;
            case 35:       setText(name, "Government", "2019", getResources().getString(R.string.s35));                                   break;
            case 36:       setText(name, "Government", "2019", getResources().getString(R.string.s36));                                   break;


        }


    }


    void setText(String name, String type1, String es1, String full){

        TextView collegeName, type, es, fulll;

        collegeName = findViewById(R.id.collegeName);
        type = findViewById(R.id.type);
        es = findViewById(R.id.es);
        fulll = findViewById(R.id.full);


        collegeName.setText(name);
        type.setText(type1);
        es.setText(es1);
fulll.setText(full);

    }
}