package com.zrax.becpredictor;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.zrax.becpredictor.databinding.ActivityFilterBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;

public class Filter extends AppCompatActivity {
    ActivityFilterBinding binding;
    String selectedCategory = "All", selectedBranch = "";

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFilterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());



        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        binding.Refresh.setOnClickListener(view -> {
            binding.branchText.setText("All");
            binding.CategoryText.setText("Open");
            binding.RankBox.setText("");
        });
        binding.branchBox.setOnClickListener(this::branch);
        binding.categoryBox.setOnClickListener(this::category);
        binding.back.setOnClickListener(view -> {
            onBackPressed();
        });

        binding.PredictCollege.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (selectedCategory.equals("")){
                    Toast.makeText(Filter.this, "Please select category", Toast.LENGTH_SHORT).show();
                }
                else if (selectedBranch.equals("")){
                    Toast.makeText(Filter.this, "Please select branch", Toast.LENGTH_SHORT).show();
                }
                else if (binding.RankBox.getText().toString().equals("")){
                    Toast.makeText(Filter.this, "Please enter rank", Toast.LENGTH_SHORT).show();
                }
                else{
                    Intent intent = new Intent(Filter.this, PredictCollege.class);
                    intent.putExtra("category", selectedCategory);
                    intent.putExtra("branch", selectedBranch);
                    intent.putExtra("rank", Integer.parseInt(binding.RankBox.getText().toString()));
                    startActivity(intent);
                }


            }
        });
    }








    void branch(View l) {
        PopupMenu pop = new PopupMenu(Filter.this, l);

        String[] branch = {
                "All",
                "I.T.",
                "COMPUTER Sc. & Engg.",
                "ELECTRO & COMMUNICATION, ENGG.",
                "ELECTRICAL ENGG.",
                "MECHANICAL ENGG.",
                "CIVIL ENGG.",
                "LEATHER TECH."
        };
        for (int i = 0; i != branch.length; i++) {
            pop.getMenu().add(branch[i]);
        }

        pop.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                binding.branchText.setText(String.valueOf(item));
                selectedBranch = String.valueOf(item);
                return false;
            }
        });

        pop.show();
    }

    void category(View l) {
        PopupMenu pop = new PopupMenu(Filter.this, l);
        String[] category = {
                "DQ",
                "SMQ",
                "UR",
                "ST",
                "SC",
                "BC",
                "EBC",
                "RCG",
                "EWS"
        };
        for (int i = 0; i != category.length; i++) {
            pop.getMenu().add(category[i]);
        }


        pop.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                binding.CategoryText.setText(String.valueOf(item));
                selectedCategory = String.valueOf(item);
                return false;
            }
        });

        pop.show();
    }


}