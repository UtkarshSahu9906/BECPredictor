package com.zrax.becpredictor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class CollegeDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college_details);
        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

      TextView a1  =   findViewById(R.id.a1 );
      TextView a2  =   findViewById(R.id.a2 );
      TextView a3  =   findViewById(R.id.a3 );
      TextView a4  =   findViewById(R.id.a4 );
      TextView a5  =   findViewById(R.id.a5 );
      TextView a6  =   findViewById(R.id.a6 );
      TextView a7  =   findViewById(R.id.a7 );
      TextView a8  =   findViewById(R.id.a8 );
      TextView a9  =   findViewById(R.id.a9 );
      TextView a10 =   findViewById(R.id.a10);
      TextView a11 =   findViewById(R.id.a11);
      TextView a12 =   findViewById(R.id.a12);
      TextView a13 =   findViewById(R.id.a13);
      TextView a14 =   findViewById(R.id.a14);
      TextView a15 =   findViewById(R.id.a15);
      TextView a16 =   findViewById(R.id.a16);
      TextView a17 =   findViewById(R.id.a17);
      TextView a18 =   findViewById(R.id.a18);
      TextView a19 =   findViewById(R.id.a19);
      TextView a20 =   findViewById(R.id.a20);
      TextView a21 =   findViewById(R.id.a21);
      TextView a22 =   findViewById(R.id.a22);
      TextView a23 =   findViewById(R.id.a23);
      TextView a24 =   findViewById(R.id.a24);
      TextView a25 =   findViewById(R.id.a25);
      TextView a26 =   findViewById(R.id.a26);
      TextView a27 =   findViewById(R.id.a27);
      TextView a28 =   findViewById(R.id.a28);
      TextView a29 =   findViewById(R.id.a29);
      TextView a30 =   findViewById(R.id.a30);
      TextView a31 =   findViewById(R.id.a31);
      TextView a32 =   findViewById(R.id.a32);
      TextView a33 =   findViewById(R.id.a33);
      TextView a34 =   findViewById(R.id.a34);
      TextView a35 =   findViewById(R.id.a35);
      TextView a36 =   findViewById(R.id.a36);










        findViewById(R.id.a1) .setOnClickListener(v -> { open(  1  , a1 .getText().toString() );      });
        findViewById(R.id.a2) .setOnClickListener(v -> { open(  2  , a2 .getText().toString() );      });
        findViewById(R.id.a3) .setOnClickListener(v -> { open(  3  , a3 .getText().toString() );      });
        findViewById(R.id.a4) .setOnClickListener(v -> { open(  4  , a4 .getText().toString() );      });
        findViewById(R.id.a5) .setOnClickListener(v -> { open(  5  , a5 .getText().toString() );      });
        findViewById(R.id.a6) .setOnClickListener(v -> { open(  6  , a6 .getText().toString() );      });
        findViewById(R.id.a7) .setOnClickListener(v -> { open(  7  , a7 .getText().toString() );      });
        findViewById(R.id.a8) .setOnClickListener(v -> { open(  8  , a8 .getText().toString() );      });
        findViewById(R.id.a9) .setOnClickListener(v -> { open(  9  , a9 .getText().toString() );      });
        findViewById(R.id.a10).setOnClickListener(v -> { open( 10 ,  a10.getText().toString());      });
        findViewById(R.id.a11).setOnClickListener(v -> { open( 11 ,  a11.getText().toString());      });
        findViewById(R.id.a12).setOnClickListener(v -> { open( 12 ,  a12.getText().toString());      });
        findViewById(R.id.a13).setOnClickListener(v -> { open( 13 ,  a13.getText().toString());      });
        findViewById(R.id.a14).setOnClickListener(v -> { open( 14 ,  a14.getText().toString());      });
        findViewById(R.id.a15).setOnClickListener(v -> { open( 15 ,  a15.getText().toString());      });
        findViewById(R.id.a16).setOnClickListener(v -> { open( 16 ,  a16.getText().toString());      });
        findViewById(R.id.a17).setOnClickListener(v -> { open( 17 ,  a17.getText().toString());      });
        findViewById(R.id.a18).setOnClickListener(v -> { open( 18 ,  a18.getText().toString());      });
        findViewById(R.id.a19).setOnClickListener(v -> { open( 19 ,  a19.getText().toString());      });
        findViewById(R.id.a20).setOnClickListener(v -> { open( 20 ,  a20.getText().toString());      });
        findViewById(R.id.a21).setOnClickListener(v -> { open( 21 ,  a21.getText().toString());      });
        findViewById(R.id.a22).setOnClickListener(v -> { open( 22 ,  a22.getText().toString());      });
        findViewById(R.id.a23).setOnClickListener(v -> { open( 23 ,  a23.getText().toString());      });
        findViewById(R.id.a24).setOnClickListener(v -> { open( 24 ,  a24.getText().toString());      });
        findViewById(R.id.a25).setOnClickListener(v -> { open( 25 ,  a25.getText().toString());      });
        findViewById(R.id.a26).setOnClickListener(v -> { open( 26 ,  a26.getText().toString());      });
        findViewById(R.id.a27).setOnClickListener(v -> { open( 27 ,  a27.getText().toString());      });
        findViewById(R.id.a28).setOnClickListener(v -> { open( 28 ,  a28.getText().toString());      });
        findViewById(R.id.a29).setOnClickListener(v -> { open( 29 ,  a29.getText().toString());      });
        findViewById(R.id.a30).setOnClickListener(v -> { open( 30 ,  a30.getText().toString());      });
        findViewById(R.id.a31).setOnClickListener(v -> { open( 31 ,  a31.getText().toString());      });
        findViewById(R.id.a32).setOnClickListener(v -> { open( 32 ,  a32.getText().toString());      });
        findViewById(R.id.a33).setOnClickListener(v -> { open( 33 ,  a33.getText().toString());      });
        findViewById(R.id.a34).setOnClickListener(v -> { open( 34 ,  a34.getText().toString());      });
        findViewById(R.id.a35).setOnClickListener(v -> { open( 35 ,  a35.getText().toString());      });
        findViewById(R.id.a36).setOnClickListener(v -> { open( 36 ,  a36.getText().toString());      });









    }

    void open(int a, String name){
        Intent intent = new Intent(this, CollegeDetails2.class);
        intent.putExtra("id", a);
        intent.putExtra("name", name);
        startActivity(intent);
    }
}