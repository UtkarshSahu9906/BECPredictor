package com.zrax.becpredictor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class offlineCoun extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offline_coun);
    }
}