package com.zrax.becpredictor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.rajat.pdfviewer.PdfViewerActivity;

public class placement extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college_details);




        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });




        findViewById(R.id.a1) .setOnClickListener(v -> { startActivity(

                // Opening pdf from assets folder

                PdfViewerActivity.Companion.launchPdfFromPath(
                        placement.this,
                        "m1.pdf",
                        "2019 pdf",
                        "assets",
                        false,
                        true
                )
        );      });
        findViewById(R.id.a2) .setOnClickListener(v -> { startActivity(

                // Opening pdf from assets folder

                PdfViewerActivity.Companion.launchPdfFromPath(
                        placement.this,
                        "m2.pdf",
                        "2019 pdf",
                        "assets",
                        false,
                        true
                )
        );      });
        findViewById(R.id.a3) .setOnClickListener(v -> { startActivity(

                // Opening pdf from assets folder

                PdfViewerActivity.Companion.launchPdfFromPath(
                        placement.this,
                        "m3.pdf",
                        "2019 pdf",
                        "assets",
                        false,
                        true
                )
        );       });

    }
}