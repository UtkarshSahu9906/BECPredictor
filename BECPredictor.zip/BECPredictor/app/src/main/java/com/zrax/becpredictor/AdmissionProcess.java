package com.zrax.becpredictor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.zrax.becpredictor.databinding.ActivityAddmissionProcessBinding;
import com.zrax.becpredictor.databinding.ActivityMainBinding;

public class AdmissionProcess extends AppCompatActivity {
    ActivityAddmissionProcessBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddmissionProcessBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }
}