package com.zrax.becpredictor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import com.zrax.becpredictor.databinding.ActivityOnlineCounslingBinding;

public class OnlineCounseling extends AppCompatActivity {
    ActivityOnlineCounslingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOnlineCounslingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        binding.OC1.setOnClickListener(view -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://surveyheart.com/form/647261d6b97c7c536669450b"));
            startActivity(browserIntent);
        });binding.OC2.setOnClickListener(view -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://surveyheart.com/form/6472621a67545653364ee5a4"));
            startActivity(browserIntent);
        }); binding.OC3.setOnClickListener(view -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://surveyheart.com/form/6461f8061d39d6296e804220"));
            startActivity(browserIntent);
        }); binding.OC4.setOnClickListener(view -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://surveyheart.com/form/64726241144349537a63cc4e"));
            startActivity(browserIntent);
        }); binding.OC5.setOnClickListener(view -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://surveyheart.com/form/64726257b97c7c536669458e"));
            startActivity(browserIntent);
        }); binding.OC6.setOnClickListener(view -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://surveyheart.com/form/647262756f41e2541245a26f"));
            startActivity(browserIntent);
        });




    }
}