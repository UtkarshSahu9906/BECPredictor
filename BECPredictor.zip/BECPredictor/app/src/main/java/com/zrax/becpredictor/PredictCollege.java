package com.zrax.becpredictor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;

public class PredictCollege extends AppCompatActivity {


    ArrayList<String> collegeNames;
    ArrayList<String> branchNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_predict_college);

        collegeNames = new ArrayList<>();
        branchNames = new ArrayList<>();


        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        predictCollege(getIntent().getStringExtra("category"),getIntent().getStringExtra("branch"),getIntent().getIntExtra("rank",0));


    }

    void predictCollege(String category, String branch, int rank)  {

       try {
           JSONObject object = new JSONObject(json());

           JSONArray array = object.getJSONArray("Table 1");

           for (int a = 0; a != array.length(); a++){

               JSONObject o = array.getJSONObject(a);




               String Inst_Name = o.getString("Inst_Name");
               String Course_Name = o.getString("Course_Name");
               String Category = o.getString("Category");
               int UR_Opening_Rank =  o.getInt("UR_Opening_Rank");
               int UR_Closing_Rank =  o.getInt("UR_Closing_Rank");
               int CAT_Opening_Rank = o.getInt("CAT_Opening_Rank");
               int CAT_Closing_Rank = o.getInt("CAT_Closing_Rank");



               if (branch.equals("All")){
                   if (category.equals("UR")){

                       if (UR_Opening_Rank <= rank && UR_Closing_Rank >= rank){

                           collegeNames.add(Inst_Name);
                           branchNames.add(Course_Name);
                           findViewById(R.id.no).setVisibility(View.GONE);

                       }

                   }
                   else if (category.equals(Category)){

                       if (CAT_Opening_Rank <= rank && CAT_Closing_Rank >= rank){

                           collegeNames.add(Inst_Name);
                           branchNames.add(Course_Name);
                           findViewById(R.id.no).setVisibility(View.GONE);
                       }

                   }

               }

               else if (Course_Name.contains(branch)){

                   if (category.equals("UR")){

                       if (UR_Opening_Rank <= rank && UR_Closing_Rank >= rank){

                           collegeNames.add(Inst_Name);
                           branchNames.add(Course_Name);
                           findViewById(R.id.no).setVisibility(View.GONE);

                       }

                   }
                   else if (category.equals(Category)){

                       if (CAT_Opening_Rank <= rank && CAT_Closing_Rank >= rank){

                           collegeNames.add(Inst_Name);
                           branchNames.add(Course_Name);
                           findViewById(R.id.no).setVisibility(View.GONE);
                       }

                   }







               }





           }


       } catch (JSONException | IOException e) {
           Toast.makeText(this, ""+ e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
           throw new RuntimeException(e);
       }


       RecyclerView rec = findViewById(R.id.rec);
       adapter adapter = new adapter(collegeNames, branchNames, this);
       rec.setAdapter(adapter);
       rec.setLayoutManager(new LinearLayoutManager(this));





    }
    String json() throws IOException {
        InputStream is = getResources().openRawResource(R.raw.college_data);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
        } catch (IOException e) {
            is.close();
        }

        return writer.toString();
    }




}
