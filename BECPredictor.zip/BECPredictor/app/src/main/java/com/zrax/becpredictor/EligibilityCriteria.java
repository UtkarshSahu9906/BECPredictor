package com.zrax.becpredictor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;

import com.zrax.becpredictor.databinding.ActivityEligibilityCriteriaBinding;

public class EligibilityCriteria extends AppCompatActivity {
    com.zrax.becpredictor.databinding.ActivityEligibilityCriteriaBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityEligibilityCriteriaBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }
}