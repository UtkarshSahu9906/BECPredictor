package com.zrax.becpredictor.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.zrax.becpredictor.AdmissionProcess;
import com.zrax.becpredictor.CollegeDetails;
import com.zrax.becpredictor.DocumentRequired;
import com.zrax.becpredictor.EligibilityCriteria;
import com.zrax.becpredictor.Filter;
import com.zrax.becpredictor.OnlineCounseling;
import com.zrax.becpredictor.PredictRankActivity;
import com.zrax.becpredictor.PreviousYear;
import com.zrax.becpredictor.R;
import com.zrax.becpredictor.WebView;
import com.zrax.becpredictor.databinding.FragmentHomeBinding;
import com.zrax.becpredictor.offlineCoun;
import com.zrax.becpredictor.placement;

import org.imaginativeworld.whynotimagecarousel.model.CarouselItem;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    List<CarouselItem> list = new ArrayList<>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();




        binding.AdmissionProcess.setOnClickListener(view -> getContext().startActivity(new Intent(getContext(), AdmissionProcess.class)));
        binding.PreviousYear.setOnClickListener(view -> getContext().startActivity(new Intent(getContext(), PreviousYear.class)));
        binding.DocumentRequired.setOnClickListener(view -> getContext().startActivity(new Intent(getContext(), DocumentRequired.class)));
        binding.CollegeDetails.setOnClickListener(view -> getContext().startActivity(new Intent(getContext(), CollegeDetails.class)));
        binding.OnlineCounsling.setOnClickListener(view -> getContext().startActivity(new Intent(getContext(), OnlineCounseling.class)));
        binding.EligibilityCritaria.setOnClickListener(view -> getContext().startActivity(new Intent(getContext(), EligibilityCriteria.class)));
        binding.PlacementInformation.setOnClickListener(view -> getContext().startActivity(new Intent(getContext(), placement.class)));

        list.add(new CarouselItem(R.drawable.d1));
        list.add(new CarouselItem(R.drawable.d2));
        list.add(new CarouselItem(R.drawable.d3));
        list.add(new CarouselItem(R.drawable.d4));

        binding.carousel.setData(list);

        binding.Youtube.setOnClickListener(view -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@collegementa9211"));
            startActivity(browserIntent);
        });
        binding.Web.setOnClickListener(view -> {
            Intent intent = new Intent(getContext(), WebView.class);
            intent.putExtra("url","https://collegementa.com");
            startActivity(intent);
        });
        binding.Facebook.setOnClickListener(view -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/profile.php?id=100020218606332"));
            startActivity(browserIntent);
        });
        binding.Linkin.setOnClickListener(view -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.linkedin.com/in/nikhil-kumar-65405425b"));
            startActivity(browserIntent);
        });
        binding.Insta.setOnClickListener(view -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/_babusaheb_09?igshid=OTk0YzhjMDVlZA=="));
            startActivity(browserIntent);
        });

        binding.RankPredictor.setOnClickListener(view -> startActivity(new Intent(getContext(), PredictRankActivity.class)));
        binding.OfflineCounsling.setOnClickListener(view -> startActivity(new Intent(getContext(), offlineCoun.class)));

        binding.recent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), WebView.class);
                intent.putExtra("url","https://collegementa.com/");
                startActivity(intent);
            }
        });

        binding.CollegePredict.setOnClickListener(view -> startActivity(new Intent(getContext(), Filter.class)));
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}