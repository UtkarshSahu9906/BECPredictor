package com.zrax.becpredictor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

public class PredictRankActivity extends AppCompatActivity {

    double percentage = 00;
    String CATEGORY = "";
    ConstraintLayout chooseCategory;
    TextView rank, categoryText;
    EditText rankET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_predict_rank);


        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        chooseCategory = findViewById(R.id.categoryBox);
        rankET = findViewById(R.id.RankBox);
        rank = findViewById(R.id.rank);
        categoryText = findViewById(R.id.CategoryText);
        chooseCategory.setOnClickListener(this::category);


        findViewById(R.id.back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });



        findViewById(R.id.PredictCollege).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (rankET.getText().toString().equals("")){
                    Toast.makeText(PredictRankActivity.this, "Please enter rank", Toast.LENGTH_SHORT).show();
                }
                else if (CATEGORY.equals("")){
                    Toast.makeText(PredictRankActivity.this, "Please choose a category", Toast.LENGTH_SHORT).show();
                }
                else{

                    boolean found = false;
                    percentage = Double.parseDouble(rankET.getText().toString());
                    try {
                        JSONObject object = new JSONObject(json());

                        JSONArray array = object.getJSONArray("table-1");

                        for (int a = 0; a != array.length(); a++){

                            JSONObject o = array.getJSONObject(a);

                            String rawPercentage = o.getString("PERCENTILE");

                            String[] separated = rawPercentage.split("-");
                            String rawPerc1 = separated[0];
                            String rawPerc2 = separated[1];

                            double per1 = Double.parseDouble(rawPerc1.replaceAll("\\s",""));
                            double per2 = Double.parseDouble(rawPerc2.replaceAll("\\s",""));


                            if (percentage >= per2 && percentage <= per1){


                                rank.setText("Rank : " + o.getString(CATEGORY));

                                found = true;
                            }



                        }



                    } catch (JSONException | IOException e) {
                        throw new RuntimeException(e);
                    }
                    if (!found){
                        rank.setText("Rank : No result");
                    }

                }



            }
        });






    }

    String json() throws IOException {
        InputStream is = getResources().openRawResource(R.raw.rank_data);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
        } catch (IOException e) {
            is.close();
        }

        return writer.toString();
    }
    void category(View l) {
        PopupMenu pop = new PopupMenu(PredictRankActivity.this, l);
        String[] category = {
                "UR",
                "EWS",
                "BC",
                "EBC",
                "SC/ST",
                "RCG",

        };
        for (int i = 0; i != category.length; i++) {
            pop.getMenu().add(category[i]);
        }


        pop.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                CATEGORY = String.valueOf(item);
                categoryText.setText(CATEGORY);
                return false;
            }
        });

        pop.show();
    }
}