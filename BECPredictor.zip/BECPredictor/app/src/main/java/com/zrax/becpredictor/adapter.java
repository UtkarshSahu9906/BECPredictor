package com.zrax.becpredictor;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adapter extends RecyclerView.Adapter {

    ArrayList<String> names, branches;
    Context context;

    public adapter(ArrayList<String> names, ArrayList<String> branches, Context context) {
        this.names = names;
        this.branches = branches;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.college_item, parent, false);


        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        ((viewHolder)holder).name.setText(names.get(position));
        ((viewHolder)holder).branch.setText(branches.get(position));



    }

    @Override
    public int getItemCount() {
        return branches.size();
    }
}
 class viewHolder extends RecyclerView.ViewHolder{

    TextView name, branch;
     public viewHolder(@NonNull View itemView) {
         super(itemView);

         name = itemView.findViewById(R.id.college_name);
         branch = itemView.findViewById(R.id.branch);


     }
 }
